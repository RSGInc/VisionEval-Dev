makeL <- function(yr,
                  modelPath,
                  withWrk = FALSE,
                  withVeh = FALSE,
                  withReg = FALSE,
                  seed = 1) {
  L <- list()
  # Load Global Datastore data
  Global <- list()
  gdirs <- list.files(paste0(modelPath, '/Global'))
  
  for (gd in gdirs) {
    gd.files <-
      list.files(paste0(modelPath, '/Global/', gd), full.names = T)
    gd.list <- lapply(gd.files, load)
    names(gd.list) <-
      gsub('.Rda', '', list.files(paste0(modelPath, '/Global/', gd)))
    if (length(gd.files) > 0) {
      for (i in 1:length(gd.files)) {
        load(gd.files[[i]])
        gd.list[[i]] <- Dataset
      }
      x <- list(gd.list)
      names(x) <- gd
      Global <- c(Global, x)
    }
  }
  
  # Load household table data
  
  Household <-
    lapply(list.files(paste0(modelPath, '/', yr, '/Household/'), full.names = T), load)
  names(Household) <-
    gsub('.Rda', '', list.files(paste0(modelPath, '/', yr, '/Household/')))
  
  hh_list <-
    list.files(paste0(modelPath, '/', yr, '/Household/'), full.names = T)
  for (i in 1:length(Household)) {
    load(hh_list[[i]])
    Household[[i]] <- Dataset
  }
  
  # Load worker tables
  
  if (withWrk == T) {
    Worker <-
      lapply(list.files(paste0(modelPath, '/', yr, '/Worker/'), full.names = T), load)
    names(Worker) <-
      gsub('.Rda', '', list.files(paste0(modelPath, '/', yr, '/Worker/')))
    v_list <-
      list.files(paste0(modelPath, '/', yr, '/Worker/'), full.names = T)
    for (i in 1:length(Worker)) {
      load(v_list[[i]])
      Worker[[i]] <- Dataset
    }
  }
  
  # Load vehicle tables
  
  if (withVeh == T) {
    Vehicle <-
      lapply(list.files(paste0(modelPath, '/', yr, '/Vehicle/'), full.names = T), load)
    names(Vehicle) <-
      gsub('.Rda', '', list.files(paste0(modelPath, '/', yr, '/Vehicle/')))
    v_list <-
      list.files(paste0(modelPath, '/', yr, '/Vehicle/'), full.names = T)
    for (i in 1:length(Vehicle)) {
      load(v_list[[i]])
      Vehicle[[i]] <- Dataset
    }
  }
  
  # Load region tables
  
  if (withReg == T) {
    Region <-
      lapply(list.files(paste0(modelPath, '/', yr, '/Region/'), full.names = T), load)
    names(Region) <-
      gsub('.Rda', '', list.files(paste0(modelPath, '/', yr, '/Region/')))
    v_list <-
      list.files(paste0(modelPath, '/', yr, '/Region/'), full.names = T)
    for (i in 1:length(Region)) {
      load(v_list[[i]])
      Region[[i]] <- Dataset
    }
  }
  
  # Load Bzone tables
  
  Bzone <-
    lapply(list.files(paste0(modelPath, '/', yr, '/Bzone/'), full.names = T), load)
  names(Bzone) <-
    gsub('.Rda', '', list.files(paste0(modelPath, '/', yr, '/Bzone/')))
  b_list <-
    list.files(paste0(modelPath, '/', yr, '/Bzone/'), full.names = T)
  for (i in 1:length(Bzone)) {
    load(b_list[[i]])
    Bzone[[i]] <- Dataset
  }
  
  # Load Azone tables
  
  Azone <-
    lapply(list.files(paste0(modelPath, '/', yr, '/Azone/'), full.names = T), load)
  names(Azone) <-
    gsub('.Rda', '', list.files(paste0(modelPath, '/', yr, '/Azone/')))
  b_list <-
    list.files(paste0(modelPath, '/', yr, '/Azone/'), full.names = T)
  for (i in 1:length(Azone)) {
    load(b_list[[i]])
    Azone[[i]] <- Dataset
  }
  
  # Load Marea tables
  
  Marea <-
    lapply(list.files(paste0(modelPath, '/', yr, '/Marea/'), full.names = T), load)
  names(Marea) <-
    gsub('.Rda', '', list.files(paste0(modelPath, '/', yr, '/Marea/')))
  b_list <-
    list.files(paste0(modelPath, '/', yr, '/Marea/'), full.names = T)
  for (i in 1:length(Marea)) {
    load(b_list[[i]])
    Marea[[i]] <- Dataset
  }
  
  # Combine loaded tables into list based on options in function
  
  if (withWrk == TRUE & withVeh == TRUE) {
    Year <- list(Vehicle, Worker, Household, Bzone, Azone, Marea)
    names(Year) <-
      c('Vehicle', 'Worker', 'Household', 'Bzone', 'Azone', 'Marea')
  }
  if (withWrk == TRUE & withVeh == FALSE) {
    Year <- list(Worker, Household, Bzone, Azone, Marea)
    names(Year) <-
      c('Worker', 'Household', 'Bzone', 'Azone', 'Marea')
  }
  if (withWrk == FALSE & withVeh == FALSE) {
    Year <- list(Household, Bzone, Azone, Marea)
    names(Year) <- c('Household', 'Bzone', 'Azone', 'Marea')
  }
  if (withWrk == TRUE & withVeh == TRUE & withReg == TRUE) {
    Year <-
      list(Vehicle, Worker, Region, Household, Bzone, Azone, Marea)
    names(Year) <-
      c('Vehicle',
        'Worker',
        'Region',
        'Household',
        'Bzone',
        'Azone',
        'Marea')
  }
  L <- list(Year, Global)
  names(L) <- c('Year', 'Global')
  L$G$Seed = seed
  L$G$Year = yr
  L$G$BaseYear = 2010
  
  return(L)
}
