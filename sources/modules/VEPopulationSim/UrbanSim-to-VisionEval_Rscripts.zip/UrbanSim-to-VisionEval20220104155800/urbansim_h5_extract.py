import os
import pandas as pd
import h5py

# set working directory

run = 'run_26'
os.chdir('/mnt/c/Users/gately/Dropbox/MAPC/VisionEval_R_4.0.0/urbansim/' + run)
years = ['2010','2011','2020','2030','2040','2050']

for yr in years:
        if not os.path.exists(yr):
            os.makedirs(yr)
    
h5=pd.HDFStore('results_mapc_' + run + '_run_results.h5')
keys = h5.keys()

for key in keys:

	out = h5[key]
	out.to_csv('.' + key + ".csv", header = True, index = False)
	print("export of " + key + " complete")
