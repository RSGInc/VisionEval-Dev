library(data.table)

baseDIR = 'C:/Users/gately/Dropbox/MAPC/VisionEval_R_4.0.0/'
modelDIR = 'C:/Users/gately/Dropbox/MAPC/VisionEval_R_4.0.0/models/MAPC_Scenarios/'

setwd(paste0(baseDIR, 'urbansim'))

# Load PUMS data
per13 <- fread('pums13_5yr/ss13pma.csv')
hh13 <- fread('pums13_5yr/ss13hma.csv')

# Format variables and column names
setnames(per13, tolower(colnames(per13)))
setnames(hh13, tolower(colnames(hh13)))
per13[, serialno := as.character(serialno)]
hh13[, serialno := as.character(serialno)]
setkey(per13, serialno)
setkey(hh13, serialno)

# Join households and persons PUMS files
pums13 <- merge(hh13, per13, all = T, allow.cartesian = T)
setnames(pums13, tolower(colnames(pums13)))
setkey(pums13, serialno)

# Subset and rename columns
pcols <-
  c(
    'serialno',
    'adjhsg',
    'adjinc.y',
    'type',
    'bld',
    'vacs',
    'valp',
    'hincp',
    'wif',
    'sporder',
    'agep',
    'wagp',
    'oip',
    'esr',
    'naicsp',
    'pincp'
  )
cn <-
  c(
    'serialno',
    'hh_adj',
    'inc_adj',
    'hh_type',
    'bld_type',
    'vacancy',
    'prop_value',
    'hh_inc',
    'workers_in_fam',
    'person_num',
    'age',
    'wage_inc',
    'other_inc',
    'emp_status',
    'naics',
    'tot_inc_person'
  )
pums13 <- pums13[, ..pcols]
setnames(pums13, cn)
pums13 <- pums13[is.na(vacancy)]
setkey(pums13, serialno)
rm(hh13, per13)
gc()

# Add dummy variable for group quarters
pums13[, gq := 0]
pums13[hh_type %in% c(2, 3), gq := 1]

# Recode UrbanSim/PUMS age groups to match VisionEval age groups
pums13[, age_grp := 1]
pums13[age >= 15 & age <= 19, age_grp := 2]
pums13[age >= 20 & age <= 29, age_grp := 3]
pums13[age >= 30 & age <= 54, age_grp := 4]
pums13[age >= 55 & age <= 64, age_grp := 5]
pums13[age >= 65 , age_grp := 6]

# Loop through VisionEval model years and UrbanSim runs to process
# UrbanSim h5 data into input format for VisionEval

modelYears = c('2010', '2030')
#runs <- c('run_24', 'run_25', 'run_26')
runs <- c('run_26')

for (yr in modelYears) {
  for (runspec in runs) {
    hh <- fread(paste0(runspec, '/', yr, '/households.csv'))
    hh[, serialno := as.character(serialno)]
    setorder(hh, serialno, block_id)
    hh[, row := .I]
    hh[, hid := paste(serialno, row, sep = '_')]
    hh <-
      hh[, .(serialno,
             block_id,
             hid,
             income,
             workers,
             persons,
             tenure,
             cars)]
    setkey(hh, serialno)
    
    # Join person-level PUMS data for each household in UrbanSim output
    hh <- merge(hh, pums13, all.x = T, allow.cartesian = T)
    hh[, is_worker := 0]
    hh[emp_status %in% c(1, 2, 4, 5), is_worker := 1]
    hh[, blockgroup_id := substr(block_id, 1, 12)]
    hh[, year := yr]
    saveRDS(hh,
            paste0(
              runspec,
              '/urbansim_',
              runspec,
              '_microhouseholds_',
              yr,
              '.rds'
            ))
    
    ## Generate compact microsimulated household files for swapping into VisionEval Datastore during runs
    
    hh[, pid := paste(serialno, person_num, sep = '_')]
    hh[is.na(tot_inc_person), tot_inc_person := 0]
    
    # Adjust income to 2010USD
    hh[, inc2010 := as.integer(round(
      as.numeric(tot_inc_person) * inc_adj / 1e6 * 237.446 / 251.139
    ))]
    hh[, hhinc2010 := as.integer(round(as.numeric(hh_inc) * inc_adj / 1e6 *
                                         237.446 / 251.139))]
    # Subset to compact form for export
    hh <-
      hh[, .(
        year,
        hid,
        pid,
        person_num,
        serialno,
        blockgroup_id,
        block_id,
        persons,
        age,
        age_grp,
        is_worker,
        workers,
        hh_type,
        gq,
        bld_type,
        inc2010,
        hhinc2010
      )]
    hids <- data.table(hid = sort(unique(hh$hid)))
    hids[, HhId := .I]
    setkey(hids, hid)
    setkey(hh, hid)
    hh <- hids[hh]
    saveRDS(
      hh,
      paste0(
        landuse,
        '/urbansim_',
        landuse,
        '_microhouseholds_brief',
        yr,
        '.rds'
      )
    )
  }
}
