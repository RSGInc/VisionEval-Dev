landuse <- substr(runspec, 1, 6)
runDIR = paste0(baseDIR, 'urbansim/',
                landuse,
                '/')

# Load VisionEval datastore into a list
LL <- makeL(yr, paste0(modelDIR, 'Datastore'))

# Make data.table of VisionEval household datastore to append group quarters data to UrbanSim
dstore <- data.table(
  HhId = LL$Year$Household$HhId,
  Azone = LL$Year$Household$Azone,
  Bzone = LL$Year$Household$Bzone,
  HouseType = LL$Year$Household$HouseType,
  HhType = LL$Year$Household$HhType,
  HhSize = LL$Year$Household$HhSize,
  Age0to14 = LL$Year$Household$Age0to14,
  Age15to19 = LL$Year$Household$Age15to19,
  Age20to29 = LL$Year$Household$Age20to29,
  Age30to54 = LL$Year$Household$Age30to54,
  Age55to64 = LL$Year$Household$Age55to64,
  Age65Plus = LL$Year$Household$Age65Plus,
  CarSvcLevel = LL$Year$Household$CarSvcLevel,
  FreeParkingSpaces = LL$Year$Household$FreeParkingSpaces,
  Income = LL$Year$Household$Income,
  IsIMP = LL$Year$Household$IsIMP,
  IsUrbanMixNbrhd = LL$Year$Household$IsUrbanMixNbrhd,
  LifeCycle = LL$Year$Household$LifeCycle,
  LocType = LL$Year$Household$LocType,
  Marea = LL$Year$Household$Marea,
  OtherParkingCost = LL$Year$Household$OtherParkingCost,
  ParkingUnitCost = LL$Year$Household$ParkingUnitCost,
  PropTdmDvmtReduction = LL$Year$Household$PropTdmDvmtReduction,
  Wkr15to19 = LL$Year$Household$Wkr15to19,
  Wkr20to29 = LL$Year$Household$Wkr20to29,
  Wkr30to54 = LL$Year$Household$Wkr30to54,
  Wkr55to64 = LL$Year$Household$Wkr55to64,
  Wkr65Plus = LL$Year$Household$Wkr65Plus,
  Workers = LL$Year$Household$Workers
)

# Subset VisionEval Households to get Group Quarters population
gq <- dstore[HouseType == 'GQ']

# Load UrbanSim household data
hh <-
  readRDS(paste0(
    runDIR,
    'urbansim_',
    landuse,
    '_microhouseholds_brief',
    yr,
    '.rds'
  ))

# Synchronize household IDs between UrbanSim and VisionEval
hh[, HhId := paste0('MAPC-', HhId)]
gq[, HhId := paste0('MAPC-', nrow(hh) + .I)]

# Add some VisionEval columns to UrbanSim for combination later
hh[, Azone := 'MAPC']
hh[, Bzone := as.character(blockgroup_id)]
hh[, Marea := 'MAPC']
hh[bld_type %in% 1:3, HouseType := 'SF']
hh[bld_type %in% 4:10, HouseType := 'MF']
hh[, HhSize := persons]
setnames(hh, 'workers', 'Workers')
setnames(hh, 'inc2010', 'Income')

# Sum UrbanSim person-records to households

# Persons by age group in each household
hh[, Age0to14 := ifelse(age_grp == 1, 1, 0)]
hh[, Age15to19 := ifelse(age_grp == 2, 1, 0)]
hh[, Age20to29 := ifelse(age_grp == 3, 1, 0)]
hh[, Age30to54 := ifelse(age_grp == 4, 1, 0)]
hh[, Age55to64 := ifelse(age_grp == 5, 1, 0)]
hh[, Age65Plus := ifelse(age_grp == 6, 1, 0)]

# Workers by age group
hh[, Wkr0to14 := ifelse(age_grp == 1 & is_worker == 1, 1, 0)]
hh[, Wkr15to19 := ifelse(age_grp == 2 & is_worker == 1, 1, 0)]
hh[, Wkr20to29 := ifelse(age_grp == 3 & is_worker == 1, 1, 0)]
hh[, Wkr30to54 := ifelse(age_grp == 4 & is_worker == 1, 1, 0)]
hh[, Wkr55to64 := ifelse(age_grp == 5 & is_worker == 1, 1, 0)]
hh[, Wkr65Plus := ifelse(age_grp == 6 & is_worker == 1, 1, 0)]

# Columns to sum
cs <-   c(
  'Income',
  'Age0to14',
  'Age15to19',
  'Age20to29',
  'Age30to54',
  'Age55to64',
  'Age65Plus',
  'Wkr0to14',
  'Wkr15to19',
  'Wkr20to29',
  'Wkr30to54',
  'Wkr55to64',
  'Wkr65Plus'
)

# Sum income, persons, workers in household
hh <-
  hh[, lapply(.SD, sum, na.rm = T), by = list(HhId, Azone, Bzone, Marea, Workers, HouseType, HhSize), .SDcols =
       (cs)]
hh[Income < 0, Income := 0]

# Create HouseType column to match VisionEval format
hh[HouseType %in% c('SF', 'MF'), HhType := paste(Age0to14,
                                                 Age15to19,
                                                 Age20to29,
                                                 Age30to54,
                                                 Age55to64,
                                                 Age65Plus,
                                                 sep = '-')]
hh[HouseType == 'GQ', HhType := 'Grp']

# Append the VisionEval Group Quarters population
hh <- rbind(hh, gq, fill = T)
setorder(hh, HhId)

###############################################################
# Transfer UrbanSim household data into the model Datastore
##############################################################

# Azone of each Household
load(paste0(modelDIR, 'Datastore/', yr, '/Household/Azone.Rda'))
atts <- attributes(Dataset)
Dataset <- rep('MAPC', dim(hh)[1])
attributes(Dataset) <- atts
save(Dataset,
     file = paste0(modelDIR, 'Datastore/', yr, '/Household/Azone.Rda'))

# Azone total number of workers
load(paste0(modelDIR, 'Datastore/', yr, '/Azone/NumWkr.Rda'))
atts <- attributes(Dataset)
Dataset <- sum(hh$Workers)
attributes(Dataset) <- atts
save(Dataset,
     file = paste0(modelDIR, 'Datastore/', yr, '/Azone/NumWkr.Rda'))

# Household ID values
load(paste0(modelDIR, 'Datastore/', yr, '/Household/HhId.Rda'))
atts <- attributes(Dataset)
Dataset <- hh$HhId
atts$SIZE <- max(nchar(Dataset))
attributes(Dataset) <- atts
save(Dataset,
     file = paste0(modelDIR, 'Datastore/', yr, '/Household/HhId.Rda'))

# Bzone location of households
load(paste0(modelDIR, 'Datastore/', yr, '/Household/Bzone.Rda'))
atts <- attributes(Dataset)
Dataset <- hh$Bzone
atts$SIZE <- max(nchar(Dataset))
attributes(Dataset) <- atts
save(Dataset,
     file = paste0(modelDIR, 'Datastore/', yr, '/Household/Bzone.Rda'))

# Number of persons by age group in each household
age_groups <-
  c('Age0to14',
    'Age15to19',
    'Age20to29',
    'Age30to54',
    'Age55to64',
    'Age65Plus')
for (a in age_groups) {
  load(paste0(modelDIR, 'Datastore/', yr, '/Household/', a, '.Rda'))
  atts <- attributes(Dataset)
  Dataset <- hh[, get(a)]
  attributes(Dataset) <- atts
  save(Dataset,
       file = paste0(modelDIR, 'Datastore/', yr, '/Household/', a, '.Rda'))
}

# Household Size
load(paste0(modelDIR, 'Datastore/', yr, '/Household/HhSize.Rda'))
atts <- attributes(Dataset)
Dataset <- hh$HhSize
attributes(Dataset) <- atts
save(Dataset,
     file = paste0(modelDIR, 'Datastore/', yr, '/Household/HhSize.Rda'))

# Household Type
load(paste0(modelDIR, 'Datastore/', yr, '/Household/HhType.Rda'))
atts <- attributes(Dataset)
Dataset <- hh$HhType
atts$SIZE <- max(nchar(Dataset))
attributes(Dataset) <- atts
save(Dataset,
     file = paste0(modelDIR, 'Datastore/', yr, '/Household/HhType.Rda'))

# Household Type
load(paste0(modelDIR, 'Datastore/', yr, '/Household/HouseType.Rda'))
atts <- attributes(Dataset)
Dataset <- hh$HouseType
atts$SIZE <- max(nchar(Dataset))
attributes(Dataset) <- atts
save(Dataset,
     file = paste0(modelDIR, 'Datastore/', yr, '/Household/HouseType.Rda'))

# Household Income
load(paste0(modelDIR, 'Datastore/', yr, '/Household/Income.Rda'))
atts <- attributes(Dataset)
Dataset <- hh$Income
atts$YEAR <- as.character(yr)
attributes(Dataset) <- atts
save(Dataset,
     file = paste0(modelDIR, 'Datastore/', yr, '/Household/Income.Rda'))

# Household Income
load(paste0(modelDIR, 'Datastore/', yr, '/Household/Marea.Rda'))
atts <- attributes(Dataset)
Dataset <- rep('MAPC', dim(hh)[1])
attributes(Dataset) <- atts
save(Dataset,
     file = paste0(modelDIR, 'Datastore/', yr, '/Household/Marea.Rda'))

# Number of workers by age group in each household
wkr_groups <-
  c('Wkr15to19',
    'Wkr20to29',
    'Wkr30to54',
    'Wkr55to64',
    'Wkr65Plus')
for (w in wkr_groups) {
  load(paste0(modelDIR, 'Datastore/', yr, '/Household/', w, '.Rda'))
  atts <- attributes(Dataset)
  Dataset <- hh[, get(w)]
  attributes(Dataset) <- atts
  save(Dataset,
       file = paste0(modelDIR, 'Datastore/', yr, '/Household/', w, '.Rda'))
}

# Total number of Workers in Household
load(paste0(modelDIR, 'Datastore/', yr, '/Household/Workers.Rda'))
atts <- attributes(Dataset)
Dataset <- hh$Workers
attributes(Dataset) <- atts
save(Dataset,
     file = paste0(modelDIR, 'Datastore/', yr, '/Household/Workers.Rda'))

message(paste0(
  runspec,
  ' ',
  yr,
  ' UrbanSim data successfully saved into VisionEval Datastore'
))

# Clean Up Environment

rm(dstore, gq, hh, LL)
gc()
